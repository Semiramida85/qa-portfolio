# Test Cases — Payment Processing API

**Module:** Payments  
**Endpoint:** `POST /api/v1/payments/process`  
**Tester:** Hanna Hvindzhyliia  
**Environment:** Staging  

---

## TC-PAY-001 · Successful payment with valid card

| Field | Value |
|-------|-------|
| **Priority** | Critical |
| **Type** | Positive |

**Preconditions:** Authenticated user, active terminal, sufficient balance.

**Request Body:**
```json
{
  "terminal_id": "TRM-12345",
  "amount": 150.00,
  "currency": "USD",
  "card_token": "tok_valid_visa"
}
```

**Expected Result:**
- Status: `200 OK`
- Body: `{ "transaction_id": "...", "status": "approved", "amount": 150.00 }`
- Transaction recorded in DB with correct `status = 'approved'`

---

## TC-PAY-002 · Payment declined — insufficient funds

| Field | Value |
|-------|-------|
| **Priority** | High |
| **Type** | Negative |

**Expected Result:**
- Status: `200 OK` (payment processed, but declined)
- Body: `{ "status": "declined", "decline_reason": "insufficient_funds" }`
- Transaction recorded in DB with `status = 'declined'`
- No money charged

---

## TC-PAY-003 · Payment with amount = 0

| Field | Value |
|-------|-------|
| **Priority** | Medium |
| **Type** | Boundary / Negative |

**Expected Result:**
- Status: `400 Bad Request`
- Error: `"amount must be greater than 0"`

---

## TC-PAY-004 · Payment with negative amount

| Field | Value |
|-------|-------|
| **Priority** | High |
| **Type** | Security / Boundary |

**Expected Result:**
- Status: `400 Bad Request`
- No transaction created in DB

---

## TC-PAY-005 · Payment to inactive terminal

| Field | Value |
|-------|-------|
| **Priority** | High |
| **Type** | Negative |

**Preconditions:** Terminal `TRM-INACTIVE` has status `inactive` in DB.

**Expected Result:**
- Status: `403 Forbidden` or `422 Unprocessable Entity`
- Error message indicating terminal is not active

---

## TC-PAY-006 · Duplicate transaction prevention (idempotency)

| Field | Value |
|-------|-------|
| **Priority** | Critical |
| **Type** | Negative / Business Logic |

**Steps:**
1. Send payment request with `idempotency_key: "key-abc-123"`
2. Send identical request again with same `idempotency_key`

**Expected Result:**
- Second request returns same `transaction_id` as first
- Only 1 transaction created in DB
- Amount charged only once

---

## TC-PAY-007 · Unauthorized payment request (no token)

| Field | Value |
|-------|-------|
| **Priority** | Critical |
| **Type** | Security |

**Steps:**
1. Send payment request without `Authorization` header

**Expected Result:**
- Status: `401 Unauthorized`
- No transaction created
