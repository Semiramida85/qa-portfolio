# Test Cases — Authentication API

**Module:** Auth  
**Endpoint:** `POST /api/v1/auth/login`  
**Tester:** Hanna Hvindzhyliia  
**Environment:** Staging  

---

## TC-001 · Successful login with valid credentials

| Field | Value |
|-------|-------|
| **ID** | TC-AUTH-001 |
| **Priority** | High |
| **Type** | Positive |

**Preconditions:** User exists in the system, account is active.

**Steps:**
1. Send `POST /api/v1/auth/login` with valid `email` and `password`
2. Check response status code
3. Check response body structure
4. Verify token is returned

**Expected Result:**
- Status: `200 OK`
- Body contains `access_token`, `token_type: "Bearer"`, `expires_in`
- Token is non-empty string

---

## TC-002 · Login with incorrect password

| Field | Value |
|-------|-------|
| **ID** | TC-AUTH-002 |
| **Priority** | High |
| **Type** | Negative |

**Steps:**
1. Send `POST /api/v1/auth/login` with valid `email` and wrong `password`

**Expected Result:**
- Status: `401 Unauthorized`
- Body: `{ "error": "invalid_credentials", "message": "..." }`
- No token in response

---

## TC-003 · Login with non-existent email

| Field | Value |
|-------|-------|
| **ID** | TC-AUTH-003 |
| **Priority** | Medium |
| **Type** | Negative |

**Steps:**
1. Send request with `email: "notexist@example.com"` and any password

**Expected Result:**
- Status: `401 Unauthorized`
- Same error as wrong password (no user enumeration vulnerability)

---

## TC-004 · Login with missing required fields

| Field | Value |
|-------|-------|
| **ID** | TC-AUTH-004 |
| **Priority** | Medium |
| **Type** | Negative / Boundary |

**Test Data Variants:**

| # | email | password | Expected Status |
|---|-------|----------|-----------------|
| a | *(empty)* | valid | `400 Bad Request` |
| b | valid | *(empty)* | `400 Bad Request` |
| c | *(missing field)* | *(missing field)* | `400 Bad Request` |

**Expected Result:**
- Status: `400 Bad Request`
- Body contains validation error details per field

---

## TC-005 · Login with malformed email format

| Field | Value |
|-------|-------|
| **ID** | TC-AUTH-005 |
| **Priority** | Low |
| **Type** | Negative / Boundary |

**Test Data:** `email: "notanemail"`, `email: "@domain.com"`, `email: "user@"`

**Expected Result:**
- Status: `400 Bad Request`
- Validation message indicating invalid email format

---

## TC-006 · Token expiration behavior

| Field | Value |
|-------|-------|
| **ID** | TC-AUTH-006 |
| **Priority** | High |
| **Type** | Negative / Security |

**Steps:**
1. Login and receive `access_token`
2. Wait for token to expire (or manually expire it in DB)
3. Make authenticated request with expired token

**Expected Result:**
- Status: `401 Unauthorized`
- Body: `{ "error": "token_expired" }`

---

## TC-007 · Response time under normal load

| Field | Value |
|-------|-------|
| **ID** | TC-AUTH-007 |
| **Priority** | Medium |
| **Type** | Performance |

**Expected Result:**
- Response time ≤ 500ms for 95th percentile under normal load
