# 👩‍💻 Hanna Hvindzhyliia — QA Portfolio

> QA Engineer | API & Backend Testing | Fintech

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue?logo=linkedin)](https://www.linkedin.com/in/hanna-hvindzhyliia-4b55762b5)
[![Telegram](https://img.shields.io/badge/Telegram-@ganna__g85-2CA5E0?logo=telegram)](https://t.me/ganna_g85)
[![Email](https://img.shields.io/badge/Email-hannahvindzhyliia@gmail.com-D14836?logo=gmail)](mailto:hannahvindzhyliia@gmail.com)

---

## 🧭 About Me

QA Engineer with commercial experience at **Nayax Retail LTD** (Israel, fintech), specializing in **API & backend testing**, log analysis, and production issue investigation.

I cover the full testing cycle — from requirements analysis to release validation — with strong SQL skills, Kibana-based debugging, and UI automation via Playwright (TypeScript).

---

## 🗂️ Portfolio Structure

| Folder | Description |
|--------|-------------|
| [`/test-cases`](./test-cases) | Manual test cases for API & UI |
| [`/bug-reports`](./bug-reports) | Real-world bug report examples |
| [`/sql`](./sql) | SQL queries for backend validation |
| [`/api-testing`](./api-testing) | Postman collections & API test examples |
| [`/playwright`](./playwright) | UI automation scripts (TypeScript) |
| [`/checklists`](./checklists) | Test checklists for common features |

---

## 🛠️ Tech Stack

**Testing:** REST API · Postman · Swagger · curl  
**Databases:** SQL · DBeaver  
**Logs & Infra:** Kibana · Argo CD · Kubernetes Lens  
**Automation:** Playwright (TypeScript) · Python (basic)  
**Tools:** Jira · Zephyr Squad · TestRail · Git  
**Formats:** JSON · XML · HTML · CSS  
**Methodology:** Scrum · SAFe Agile  

---

## 💼 Work Experience

### QA Engineer — Nayax Retail LTD *(Jun 2025 – Present)*
International fintech company (Israel). Cashless payment solutions for unattended retail.

- End-to-end testing: requirements → test design → execution → release validation
- Deep API validation via Postman, Swagger, curl (response structure, edge cases, error handling)
- Production issue investigation via Kibana logs, Argo CD, Kubernetes Lens
- SQL backend validation: JOINs, filtering, data consistency checks
- AI-assisted workflows (Claude): test case generation, bug analysis, Jira API automation
- Regression cycles before releases in Agile environment

---

## 📬 Contact

- 📧 hannahvindzhyliia@gmail.com  
- 💬 Telegram: [@ganna_g85](https://t.me/ganna_g85)  
- 🔗 [LinkedIn](https://www.linkedin.com/in/hanna-hvindzhyliia-4b55762b5)  
- 📍 Odesa, Ukraine / Remote
