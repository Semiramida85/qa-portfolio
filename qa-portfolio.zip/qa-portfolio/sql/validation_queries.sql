# SQL Queries — Backend Data Validation

> Queries used for backend validation in QA practice at fintech company.  
> Table/column names are generalized.

---

## 1. Verify transaction was created correctly

```sql
-- Check transaction exists with correct status and amount
SELECT
    id,
    terminal_id,
    amount,
    currency,
    status,
    created_at,
    updated_at
FROM transactions
WHERE id = 'txn_9987';
```

---

## 2. Find all failed transactions for a terminal in last 24 hours

```sql
SELECT
    id,
    terminal_id,
    amount,
    status,
    decline_reason,
    created_at
FROM transactions
WHERE terminal_id = 'TRM-00123'
  AND status IN ('declined', 'failed')
  AND created_at >= NOW() - INTERVAL '24 hours'
ORDER BY created_at DESC;
```

---

## 3. Check for duplicate transactions (idempotency validation)

```sql
-- Find potential duplicates: same terminal, amount, within 1 minute
SELECT
    terminal_id,
    amount,
    currency,
    COUNT(*) AS duplicate_count,
    MIN(created_at) AS first_occurrence,
    MAX(created_at) AS last_occurrence
FROM transactions
WHERE created_at >= NOW() - INTERVAL '1 hour'
GROUP BY terminal_id, amount, currency
HAVING COUNT(*) > 1
ORDER BY duplicate_count DESC;
```

---

## 4. Validate user balance after transaction

```sql
-- Before test: record initial balance
-- After transaction: verify balance decreased by correct amount
SELECT
    u.id,
    u.email,
    a.balance,
    a.currency,
    a.updated_at
FROM users u
JOIN accounts a ON a.user_id = u.id
WHERE u.email = 'testuser@example.com';
```

---

## 5. Check transaction status matches event log

```sql
-- Verify final status in transactions table matches last event in audit log
SELECT
    t.id AS transaction_id,
    t.status AS current_status,
    el.event_type AS last_event,
    el.created_at AS last_event_time
FROM transactions t
JOIN (
    SELECT DISTINCT ON (transaction_id)
        transaction_id,
        event_type,
        created_at
    FROM event_log
    ORDER BY transaction_id, created_at DESC
) el ON el.transaction_id = t.id
WHERE t.id = 'txn_9987';
```

---

## 6. Find terminals with no activity in last 7 days

```sql
-- Used to verify inactive terminal logic in tests
SELECT
    t.id,
    t.name,
    t.status,
    MAX(tr.created_at) AS last_transaction
FROM terminals t
LEFT JOIN transactions tr ON tr.terminal_id = t.id
GROUP BY t.id, t.name, t.status
HAVING MAX(tr.created_at) < NOW() - INTERVAL '7 days'
    OR MAX(tr.created_at) IS NULL
ORDER BY last_transaction DESC NULLS LAST;
```

---

## 7. Validate refund is correctly linked to original transaction

```sql
SELECT
    r.id AS refund_id,
    r.original_transaction_id,
    r.amount AS refund_amount,
    t.amount AS original_amount,
    r.status AS refund_status,
    r.created_at
FROM refunds r
JOIN transactions t ON t.id = r.original_transaction_id
WHERE r.original_transaction_id = 'txn_9987';
```

---

## 8. Count transactions by status for a date range (smoke check)

```sql
SELECT
    status,
    COUNT(*) AS count,
    SUM(amount) AS total_amount,
    AVG(amount) AS avg_amount
FROM transactions
WHERE created_at BETWEEN '2025-07-01' AND '2025-07-31'
GROUP BY status
ORDER BY count DESC;
```

---

## 9. Check user role and permissions

```sql
SELECT
    u.id,
    u.email,
    r.name AS role,
    array_agg(p.permission_key) AS permissions
FROM users u
JOIN user_roles ur ON ur.user_id = u.id
JOIN roles r ON r.id = ur.role_id
JOIN role_permissions rp ON rp.role_id = r.id
JOIN permissions p ON p.id = rp.permission_id
WHERE u.email = 'testuser@example.com'
GROUP BY u.id, u.email, r.name;
```

---

## 10. Verify data consistency after migration / release

```sql
-- Check for orphaned records (transactions without a terminal)
SELECT t.id, t.terminal_id, t.created_at
FROM transactions t
LEFT JOIN terminals term ON term.id = t.terminal_id
WHERE term.id IS NULL;

-- Check for NULL values in non-nullable business fields
SELECT COUNT(*) AS null_amount_count
FROM transactions
WHERE amount IS NULL OR currency IS NULL OR status IS NULL;
```
