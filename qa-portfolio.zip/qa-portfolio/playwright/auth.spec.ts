import { test, expect } from '@playwright/test';

/**
 * Test Suite: Authentication
 * Module: Login Page
 * Author: Hanna Hvindzhyliia
 */

const BASE_URL = process.env.BASE_URL || 'https://staging.example.com';

test.describe('Login Page', () => {

  test.beforeEach(async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
  });

  test('TC-001 | Successful login with valid credentials', async ({ page }) => {
    await page.fill('[data-testid="email-input"]', 'qa_test@example.com');
    await page.fill('[data-testid="password-input"]', 'SecurePass123!');
    await page.click('[data-testid="login-button"]');

    await expect(page).toHaveURL(`${BASE_URL}/dashboard`);
    await expect(page.locator('[data-testid="user-menu"]')).toBeVisible();
  });

  test('TC-002 | Login with incorrect password shows error', async ({ page }) => {
    await page.fill('[data-testid="email-input"]', 'qa_test@example.com');
    await page.fill('[data-testid="password-input"]', 'WrongPassword!');
    await page.click('[data-testid="login-button"]');

    const errorMessage = page.locator('[data-testid="error-message"]');
    await expect(errorMessage).toBeVisible();
    await expect(errorMessage).toContainText('Invalid credentials');
    await expect(page).toHaveURL(`${BASE_URL}/login`);
  });

  test('TC-003 | Login button is disabled when fields are empty', async ({ page }) => {
    const loginButton = page.locator('[data-testid="login-button"]');
    await expect(loginButton).toBeDisabled();

    await page.fill('[data-testid="email-input"]', 'test@example.com');
    await expect(loginButton).toBeDisabled(); // still disabled, password empty

    await page.fill('[data-testid="password-input"]', 'somepassword');
    await expect(loginButton).toBeEnabled();
  });

  test('TC-004 | Email field validation — invalid format', async ({ page }) => {
    await page.fill('[data-testid="email-input"]', 'notanemail');
    await page.fill('[data-testid="password-input"]', 'SomePass123!');
    await page.click('[data-testid="login-button"]');

    const emailError = page.locator('[data-testid="email-error"]');
    await expect(emailError).toBeVisible();
    await expect(emailError).toContainText('valid email');
  });

  test('TC-005 | Password field masks input', async ({ page }) => {
    const passwordInput = page.locator('[data-testid="password-input"]');
    await expect(passwordInput).toHaveAttribute('type', 'password');
  });

  test('TC-006 | Show/hide password toggle works', async ({ page }) => {
    const passwordInput = page.locator('[data-testid="password-input"]');
    const toggleButton = page.locator('[data-testid="password-toggle"]');

    await page.fill('[data-testid="password-input"]', 'MyPassword');
    await expect(passwordInput).toHaveAttribute('type', 'password');

    await toggleButton.click();
    await expect(passwordInput).toHaveAttribute('type', 'text');

    await toggleButton.click();
    await expect(passwordInput).toHaveAttribute('type', 'password');
  });

});

test.describe('Dashboard — Transactions', () => {

  test.beforeEach(async ({ page }) => {
    // Login before each test
    await page.goto(`${BASE_URL}/login`);
    await page.fill('[data-testid="email-input"]', 'qa_test@example.com');
    await page.fill('[data-testid="password-input"]', 'SecurePass123!');
    await page.click('[data-testid="login-button"]');
    await page.waitForURL(`${BASE_URL}/dashboard`);
  });

  test('TC-010 | Transactions table loads with data', async ({ page }) => {
    await page.goto(`${BASE_URL}/transactions`);

    const table = page.locator('[data-testid="transactions-table"]');
    await expect(table).toBeVisible();

    const rows = page.locator('[data-testid="transaction-row"]');
    await expect(rows).toHaveCount(await rows.count()); // at least 1 row
    expect(await rows.count()).toBeGreaterThan(0);
  });

  test('TC-011 | Filter transactions by status "Approved"', async ({ page }) => {
    await page.goto(`${BASE_URL}/transactions`);

    await page.selectOption('[data-testid="status-filter"]', 'approved');

    const rows = page.locator('[data-testid="transaction-row"]');
    const count = await rows.count();

    for (let i = 0; i < count; i++) {
      const statusCell = rows.nth(i).locator('[data-testid="status-cell"]');
      await expect(statusCell).toHaveText('Approved');
    }
  });

  test('TC-012 | Transaction detail page opens correctly', async ({ page }) => {
    await page.goto(`${BASE_URL}/transactions`);

    const firstRow = page.locator('[data-testid="transaction-row"]').first();
    const transactionId = await firstRow.locator('[data-testid="transaction-id"]').textContent();

    await firstRow.click();

    await expect(page).toHaveURL(new RegExp(`/transactions/`));
    await expect(page.locator('[data-testid="detail-transaction-id"]')).toContainText(transactionId!);
  });

});
